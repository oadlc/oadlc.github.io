import cv2
import time
import requests
import numpy as np
import threading
import socket
from inverse_kinematics import inverse_kinematics

stream_url = "http://192.168.4.1:81/stream"
servo_url = "http://192.168.4.1/servo"

cap = cv2.VideoCapture(stream_url)

# PID Constants
kPx, kIx, kDx = 2.6, 0, 1  #I was at 1, D was at 1
kPy, kIy, kDy = 2.6, 0, 1   #P at 2.6

# For lab: L-S = 50, L-V = 175
# For CEID: L-S = 50, L-V = 155

# Ball color HSV thresholds: orange ping pong balls typically sit around H = 5-20 depending on lighting
lower_orange = np.array([5, 50, 155])
upper_orange = np.array([20, 255, 255])

# PID state constants
prev_error_x = 0.0
prev_error_y = 0.0
integral_x = 0.0
integral_y = 0.0

# PID controller on the x coordinates of the ball
def pid_x(error_x, dt):
    global prev_error_x, integral_x
    # Proportional term
    Px = kPx * error_x
    # Integral term
    integral_x += error_x * dt
    integral_x = np.clip(integral_x, -30, 30)
    Ix = kIx * integral_x
    # Derivative term. Makes sure we avoid division by 0
    Dx = kDx * (error_x - prev_error_x) / dt if dt > 0 else 0.0
    prev_error_x = error_x
    return Px + Ix + Dx

# PID controller on the y coordinates of the ball
def pid_y(error_y, dt):
    global prev_error_y, integral_y
    Py = kPy * error_y
    integral_y += error_y * dt
    integral_y = np.clip(integral_y, -30, 30)
    Iy = kIy * integral_y
    Dy = kDy * (error_y - prev_error_y) / dt if dt > 0 else 0.0
    prev_error_y = error_y
    return Py + Iy + Dy

MAX_PID_OUTPUT = 500  # tune this to roughly PID output
MAX_TILT_DEG   = 10

def scale_to_tilt(pid_output, max_pid=MAX_PID_OUTPUT, max_tilt=MAX_TILT_DEG):
    # Linearly maps [-max_pid, +max_pid] -> [-max_tilt, +max_tilt]
    # Still clamps at the ends so truly extreme values don't slip through
    ratio = pid_output / max_pid
    return max(-max_tilt, min(max_tilt, ratio * max_tilt))

# This function returns the x and y coordinates of the centroid of the largest orange blob
def find_ball(frame):
    # The frame returns an image in RGB. So we convert from RGB to HSV space
    # because it is much more convenient for color detection
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    # This makes a binary mask, where the orange ball becomes white, and everything else becomes black
    mask = cv2.inRange(hsv, lower_orange, upper_orange)

    # Removes tiny isolated white spots caused by noise, and then dialtes white
    # spots to restore ball size
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None, mask

    # Largest contour = the ball (assuming nothing else orange is in frame)
    largest = max(contours, key=cv2.contourArea)
    # Filters out tiny noise blobs
    if cv2.contourArea(largest) < 50:
        return None, mask
    
    # Returns the radius and position of the ball
    (x, y), radius = cv2.minEnclosingCircle(largest)
    # Returns the position of the ball and the color mask so that it can be showed
    return (int(x), int(y)), mask


# New Servo function, implements UPD
class ServoSender:
    def __init__(self, ip, port=9000):
        # Stores the destination as a tuple
        self.addr = (ip, port)
        # Creates the socket itself. AF_INET means IPv4
        # SOCK_DGRAM is the formal name for a UDP packet
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def send(self, a1, a2, a3):
        # Casts ints because the IK returns floats
        a1, a2, a3 = int(a1), int(a2), int(a3)
        # The checksum is the sum of the three angles appended to the message
        # If a packet gets corrupted in transit, the ESP32 recomputes the checksum and
        # compares it to the recieved checksum. If they don't match, the packet gets dropped
        # rather than moving the servo to a garbage angle
        checksum = a1 + a2 + a3
        msg = f"{a1},{a2},{a3},{checksum}"
        try:
            # msg.encode() convers the Python string to raw bytes
            # .sendto() needs the message and the destination address
            self.sock.sendto(msg.encode(), self.addr)
        except OSError as e:
            print(e)

    def stop(self):
        self.sock.close()

# Main loop
prev_time = time.perf_counter()
# Calling this immediately starts the background thread
# servo_sender = ServoSender(servo_url)
servo_sender = ServoSender("192.168.4.1", port=9000)

DEADBAND_PX = 5

while True:
    ret, frame = cap.read()
    if not ret:
        print("Failed to grab frame")
        break

    height, width = frame.shape[:2]
    center_x = width // 2
    center_y = height // 2

    now = time.perf_counter()
    dt = now - prev_time
    prev_time = now


    ball_pos, mask = find_ball(frame)

    if ball_pos is not None:
        bx, by = ball_pos
        cv2.circle(frame, (bx, by), 5, (0, 255, 0), -1)

        error_x = center_x - bx
        error_y = center_y - by

        raw_x = pid_x(error_x, dt)
        raw_y = pid_y(error_y, dt)

        if abs(error_x) < DEADBAND_PX & abs(error_y) < DEADBAND_PX:
            theta_x = 0
            theta_y = 0
        else:
            theta_x = scale_to_tilt(raw_x)
            theta_y = scale_to_tilt(raw_y)


        print(f"ex={error_x:+.0f}  ey={error_y:+.0f}  tx={theta_x:+.2f}  ty={theta_y:+.2f}")

        try:
            a1, a2, a3 = inverse_kinematics(theta_x, theta_y)
            servo_sender.send(a1, a2, a3)
        except ValueError as e:
            print(f"IK out of range: {e}")
    else:
    # Ball not found. Level platform and clear integral so it
    # doesn't build up while the ball is out of view
        integral_x = 0.0
        integral_y = 0.0
        prev_error_x = 0.0
        prev_error_y = 0.0
        servo_sender.send(90, 90, 90)

    cv2.imshow("ESP32 Camera", frame)
    # Displays the color mask (orange ball should appear white and everything else black)
    cv2.imshow("Mask", mask)
    if cv2.waitKey(1) == 27:  # ESC
        break

cap.release()
cv2.destroyAllWindows()
servo_sender.stop()