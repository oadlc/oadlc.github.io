
#Command = 90 measured Z = 101.6mm . So the calibration offset is 251.3 degrees. Measure this again next time you do it

import math

L1 = 60.42        # mm, servo shaft center to pin joint center
L2 = 108.0        # mm, pin joint center to ball joint center
D_OFFSET = 24   # mm, horizontal distance from servo shaft to ball joint

# --- Per-leg calibration offsets (degrees) ---
# command = offset - theta_mechanical
LEG_OFFSETS_DEG = {
    "leg1": 251.3,
    "leg2": 254,
    "leg3": 251.3, 
}

# Where each leg's ball joint attaches on the platform (in millimeters), relative to its
# center, on a circle of radius R at 0/120/240 degrees.
PLATFORM_RADIUS = 100

# Nominal platform height (mm) at zero tilt. Pick something safely inside
# every leg's reachable window (leg1's window is roughly 101.6mm-168mm --
# confirm the other two legs' windows once they're calibrated).
# So find the servo commands needed for this height.
NOMINAL_HEIGHT = 120.0


# Takes the tilt angles (radians) and turns them into the required height for each leg.
# Uses the function Z(x, y) = z0 + ax + by, where a and b are the slope per unit of increase
# in the x and y direction. 
# Note that the tilt is just the output from the PID equations in the x and y.
def tilt_to_leg_heights(tilt_x_rad, tilt_y_rad, z0=NOMINAL_HEIGHT):
    a = math.tan(tilt_x_rad)
    b = math.tan(tilt_y_rad)
    R = PLATFORM_RADIUS
    z1 = z0 + a*R*math.cos(math.radians(0)) + b*R*math.sin(math.radians(0))
    z2 = z0 + a*R*math.cos(math.radians(120)) + b*R*math.sin(math.radians(120))
    z3 = z0 + a*R*math.cos(math.radians(240)) + b*R*math.sin(math.radians(240))
    return z1, z2, z3


# Two-circle Inverse Kinematics. This function finds the true mechanical crank angle from the target
# height
def height_to_mechanical_deg(z, l1=L1, l2=L2, d=D_OFFSET):
    D = math.hypot(d, z)
    if not (abs(l1 - l2) <= D <= l1 + l2):
        raise ValueError(f"Height {z:.1f}mm is unreachable with L1={l1}, L2={l2}")

    # Angle between the horizontal and the hypotnuse D
    phi = math.atan2(z, d) 
    # Angle between the hypotnuse D and the crank arm: uses the Law of Cosines
    cos_alpha = (l1**2 + D**2 - l2**2) / (2 * l1 * D)
    cos_alpha = max(-1.0, min(1.0, cos_alpha))  # guard error at the limits
    alpha = math.acos(cos_alpha)
    # Angle between the horizontal and the crank arm
    mechanical_angle = phi + alpha

    return math.degrees(mechanical_angle)

# This function finds the servo command angle from the mechanical crank angle
def mechanical_angle_to_command(z, leg_offset_deg, l1=L1, l2=L2, d=D_OFFSET):
    mechanical_angle = height_to_mechanical_deg(z, l1, l2, d)
    command = leg_offset_deg - mechanical_angle

    if not (0 <= command <= 180):
        raise ValueError(f"Height {z:.1f}mm needs command {command:.1f}, outside servo range")
    return command

# Maps desired platform tilt (theta_x, theta_y) in degrees to the three servo commands
# [a1, a2, a3], using the platform's tilt plan and each leg's own measured crank/rod geometry
def inverse_kinematics(theta_x, theta_y):
    z1, z2, z3 = tilt_to_leg_heights(math.radians(theta_x), math.radians(theta_y))

    a1 = mechanical_angle_to_command(z1, LEG_OFFSETS_DEG["leg1"])
    a2 = mechanical_angle_to_command(z2, LEG_OFFSETS_DEG["leg2"])
    a3 = mechanical_angle_to_command(z3, LEG_OFFSETS_DEG["leg3"])

    return a1, a2, a3

# Highest Z a leg can physically reach (full crank)
def max_height_mm(l1=L1, l2=L2, d=D_OFFSET):
    d_max = l1 + l2
    return math.sqrt(d_max**2 - d**2)

# Servo command at full leg extension - do not command past this
def max_command(leg_offset_deg, l1=L1, l2=L2, d=D_OFFSET):
    z_max = max_height_mm(l1, l2, d)
    theta_max = height_to_mechanical_deg(z_max, l1, l2, d)
    return leg_offset_deg - theta_max


if __name__ == "__main__":
    # Quick standalone sanity check, run with: python3 inverse_kinematics.py
    offset = LEG_OFFSETS_DEG["leg1"]
    print(f"Z=101.6mm -> command={mechanical_angle_to_command(101.6, offset):.1f}")
    print(f"Z=130mmm -> command={mechanical_angle_to_command(130, offset):.1f} ")
    print(f"Z=140mm -> command={mechanical_angle_to_command(140, offset):.1f} ")
    print(f"Z=150mm -> command={mechanical_angle_to_command(150, offset):.1f}  ")
    print(f"Z=160mm -> command={mechanical_angle_to_command(160, offset):.1f}  ")
    print(f"Z=167.9mm -> command={mechanical_angle_to_command(167.9, offset):.1f}  ")

    z_max = max_height_mm()
    print(f"leg1 max reachable height: {z_max:.1f}mm at command={max_command(offset):.1f}")

    print(f"inverse_kinematics(0, 0) needs leg2/leg3 offsets -- expect a ValueError below:")
    try:
        print(inverse_kinematics(0.0, 0.0))
    except ValueError as e:
        print(f"  {e}")
