#include "servo_control.h"

// The camera claims LEDC_CHANNEL_0 directly via low-level ESP-IDF calls for
// its XCLK pixel clock signal -- this is completely invisible to Arduino's ledc /
// ESP32Servo channel bookkeeping. ESP32Servo's automatic channel picker has
// no way to know channel 0 is taken, so its first attach() call can (and
// did) grab channel 0 and stomp on the camera's pixel clock right after
// init succeeded. In turn, what was supposed to be a 20MHz clock signal going out of
// LEDC_Channel_0, LEDC_Channel_0 was reconfigured to a 50Hz servo signal

// Fix: drive these three servos with raw LEDC calls on explicit channels
// 1, 2, 3. No auto-allocation and no possible ambguity for who gets channel 0

// Standard analog PWM frequency of 50Hz
#define SERVO_FREQ_HZ  50
#define SERVO_RES_BITS 16
#define SERVO_MIN_US   600
#define SERVO_MAX_US   2400

#define SERVO1_PIN 12
#define SERVO2_PIN 13
#define SERVO3_PIN 15

// The explicit, hard-coded, LEDC timer channels
// Skips over channel 0 because that is used by the camera pixel clock
#define SERVO1_CHANNEL 1
#define SERVO2_CHANNEL 2
#define SERVO3_CHANNEL 3

// Arduino-ESP32 core 3.x renamed the LEDC API (ledcAttachChannel / ledcWrite
// keyed by pin). Core 2.x used ledcSetup + ledcAttachPin / ledcWrite keyed
// by channel. This covers both without you needing to know which you have --
// if ESP_ARDUINO_VERSION_MAJOR isn't defined at all (older 2.x), the
// preprocessor treats it as 0 and falls through to the #else branch.
static void servoAttach(uint8_t pin, uint8_t channel) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttachChannel(pin, SERVO_FREQ_HZ, SERVO_RES_BITS, channel);
#else
  ledcSetup(channel, SERVO_FREQ_HZ, SERVO_RES_BITS);
  ledcAttachPin(pin, channel);
#endif
}
void servoWriteAngle(uint8_t pin, uint8_t channel, int angle) {
  // Clamps the input against possible garbage values
  angle = constrain(angle, 0, 180);
  // Maps an angle to a pulse between 600us and 2400us
  uint32_t pulse_us = map(angle, 0, 180, SERVO_MIN_US, SERVO_MAX_US);
  // Finds the period of the signal. This number is 20,000us
  const uint32_t period_us = 1000000UL / SERVO_FREQ_HZ;
  // The maximum duty value the the LEDC register can hold at 16 bit resolution
  const uint32_t max_duty = (1UL << SERVO_RES_BITS) - 1;
  // Conversion to solve for the true duty value
  uint32_t duty = (uint64_t)pulse_us * max_duty / period_us;

// This function addresses the actual duty register
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(pin, duty);
#else
  ledcWrite(channel, duty);
#endif
}

void setupServos() {
  // Initializes all three servo channels at boot explicitly
  servoAttach(SERVO1_PIN, SERVO1_CHANNEL);
  servoAttach(SERVO2_PIN, SERVO2_CHANNEL);
  servoAttach(SERVO3_PIN, SERVO3_CHANNEL);

  // Center all three on startup.
  servoWriteAngle(SERVO1_PIN, SERVO1_CHANNEL, 90);
  servoWriteAngle(SERVO2_PIN, SERVO2_CHANNEL, 90);
  servoWriteAngle(SERVO3_PIN, SERVO3_CHANNEL, 90);
}

// This URI handler function was made initially for an HTTP connection, but decided to stick with a UDP connection
// instead because there were several timeouts with the HTTP connection. This function isn't used at all by the code
// Every URI handler takes in httpd_req_t and returns esp_err_t
esp_err_t servo_handler(httpd_req_t *req) {
  // Gets the length of the raw query string. The +1 to leave room for NULL terminator
  size_t buf_len = httpd_req_get_url_query_len(req) + 1;
  if (buf_len <= 1) {
    // There is no query string at all, servos were hit with no params
    Serial.println("[servo_handler] no query string received");
    httpd_resp_send_404(req);
    return ESP_FAIL;
  }

  // Malloc to allocate a buffer exactly sized to the query string
  // If the heap is exhausted, respond 500 instead of crashing
  char *buf = (char *)malloc(buf_len);
  if (!buf) {
    httpd_resp_send_500(req);
    return ESP_FAIL;
  }

  // Actually copies the query string into buf, and if that somewhow fails, free the buffer
  if (httpd_req_get_url_query_str(req, buf, buf_len) != ESP_OK) {
    free(buf);
    httpd_resp_send_404(req);
    return ESP_FAIL;
  }


  // Fixed-size stack values for each parameter's value: 8 bytes is enough for 180-0 plus margin
  char a1_str[8], a2_str[8], a3_str[8];
  // Only ends up true if all 3 parameters were found in their buffers
  bool ok = httpd_query_key_value(buf, "a1", a1_str, sizeof(a1_str)) == ESP_OK
         && httpd_query_key_value(buf, "a2", a2_str, sizeof(a2_str)) == ESP_OK
         && httpd_query_key_value(buf, "a3", a3_str, sizeof(a3_str)) == ESP_OK;
  // The raw query buffer's job is done, so it is freed immediately
  free(buf);

  if (!ok) {
    httpd_resp_set_status(req, "400 Bad Request");
    return httpd_resp_send(req, "Missing args", HTTPD_RESP_USE_STRLEN);
  }
  int a1 = atoi(a1_str), a2 = atoi(a2_str), a3 = atoi(a3_str);
  Serial.printf("[servo_handler] parsed angles -> a1=%d a2=%d a3=%d\n", a1, a2, a3);

  // Converts each string to int and then actuates. Atoi returns 0 on an unparseable input
  // rather than erroring it. The second's thread only job is to take the latest servo angles and send
  // thenm to the ESP32 (helps prevent stale messages and long backlog of servo angles waiting in the buffer)
  servoWriteAngle(SERVO1_PIN, SERVO1_CHANNEL, a1);
  servoWriteAngle(SERVO2_PIN, SERVO2_CHANNEL, a2);
  servoWriteAngle(SERVO3_PIN, SERVO3_CHANNEL, a3);

  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  return httpd_resp_send(req, "OK", HTTPD_RESP_USE_STRLEN);
}