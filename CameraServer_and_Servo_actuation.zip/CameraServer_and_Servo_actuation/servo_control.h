#ifndef SERVO_CONTROL_H
#define SERVO_CONTROL_H

#include <Arduino.h>
#include "esp_http_server.h"

#define SERVO1_PIN     12
#define SERVO2_PIN     13
#define SERVO3_PIN     15

#define SERVO1_CHANNEL 1
#define SERVO2_CHANNEL 2
#define SERVO3_CHANNEL 3

void setupServos();
void servoWriteAngle(uint8_t pin, uint8_t channel, int angle);
esp_err_t servo_handler(httpd_req_t *req);

#endif